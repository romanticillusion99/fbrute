# Fbbrute
Kalau bisa jadi pembuat kenapa harus jadi peminta

  [ Contact me on Whatsapp : 085268345036 ]

[Proses instalasi]
$ apt update && apt upgrade -y
$ pkg install python
$ pkg install git
$ git clone https://github.com/asmin19/brute
$ cd brute
$ pip install requests
$ pip install beautifulsoup4
$ python brutefb.py


# Enjoyy
